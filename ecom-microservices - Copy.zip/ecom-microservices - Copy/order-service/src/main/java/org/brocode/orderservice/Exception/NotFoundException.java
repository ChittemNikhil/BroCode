package org.brocode.orderservice.Exception;

public class NotFoundException extends Exception{

    public NotFoundException(String message){
        super(message);
    }
}
