package org.brocode.inventoryservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcomMicroservicesApplication {

    public static void main(String[] args) {
        SpringApplication.run(EcomMicroservicesApplication.class, args);
    }

}
